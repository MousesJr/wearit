console.log('main.js');
var request = new XMLHttpRequest();
var d = Date();
d = d[0]+d[1]+d[2];
const windClassif = document.getElementById('windClassif');
var weather, data;
//ID de Rio Grande:
request.open('GET', 'https://apiadvisor.climatempo.com.br/api/v1/forecast/locale/5368/days/15?token=63ffa13884c02106a0b4e2bb20d876f3', true);
request.onload = function () {
    data = JSON.parse(this.response);
    weather = data.data[0];
    console.log(weather);
    localStorage.setItem('cityName', data.name);
    localStorage.setItem('cityState', data.state);
    localStorage.setItem('cityCountry', data.country);
    if (request.status >= 200 && request.status < 400) {
        document.getElementById('date').textContent = d + ' ' + weather.date_br;
        //Wind
        document.getElementById('velocity').textContent = 'From ' + weather.wind.velocity_min + 'km/h to ' + weather.wind.velocity_max + 'km/h';
        if (weather.wind.velocity_max<=18) {
            windClassif.textContent = 'Weak';
            localStorage.setItem('windClass', 'weak');
        }
        if (weather.wind.velocity_max>18 && weather.wind.velocity_max<=35) {
            console.log('oi');
            windClassif.textContent = 'Moderated';
            localStorage.setItem('windClass', 'moderated');
        }
        if (weather.wind.velocity_max>35  && weather.wind.velocity_max<=44) {
            windClassif.textContent = 'Strong';
            localStorage.setItem('windClass', 'strong');
        }
        if (weather.wind.velocity_max>44) {
            windClassif.textContent = 'Storm'; 
            localStorage.setItem('windClass', 'storm');
        }
        // //Temperature
        var min = parseInt(((weather.temperature.afternoon.min + weather.temperature.morning.min + weather.temperature.night.min)/3)*10)/10;
        var max = parseInt(((weather.temperature.afternoon.max + weather.temperature.morning.max + weather.temperature.night.max)/3)*10)/10;
        document.getElementById('temp').textContent = 'From ' + min + 'Cº to ' + max + ' Cº';
        document.getElementById('thermalSenseMin').textContent = 'Min ' + weather.thermal_sensation.min +' Cº'; 
        document.getElementById('thermalSenseMax').textContent =    'Max ' + weather.thermal_sensation.max + ' Cº';
        localStorage.setItem('tempStatus', '');
        if(min<5) {
            localStorage.tempStatus = 1;
        }
        if(min>=5 && min<10) {
            localStorage.tempStatus = 2;
        }
        if(min>=10 && min<15) {
            localStorage.tempStatus = 3;
        }
        if(min>=15 && min<20) {
            localStorage.tempStatus = 4;
        }
        if(min>=20) {
            localStorage.tempStatus = 5;
        }
    } else {
        console.log('ERROR');
    }
}
request.send();