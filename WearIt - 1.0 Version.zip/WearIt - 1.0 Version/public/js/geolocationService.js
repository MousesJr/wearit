console.log('geolocation.js');
const coords = document.getElementById('coords');
if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(
        function (position) {
            var pos = {
                lat: position.coords.latitude,
                lng: position.coords.longitude
            };
            console.log('Lat: ' + pos.lat + ' Lng: ' + pos.lng);
            localStorage.setItem('positionCoords', pos.lat+'#'+pos.lng);
            console.log('PositionCoords: '+localStorage.positionCoords);
            coords.textContent = "Coords: " +  localStorage.positionCoords.split('#')[0] + ", " + localStorage.positionCoords.split('#')[1]; 
        })
} else {
    alert('Geolocation Failed!');
}
document.getElementById('place').textContent = localStorage.cityName + ', ' + localStorage.cityState + ' - ' + localStorage.cityCountry;