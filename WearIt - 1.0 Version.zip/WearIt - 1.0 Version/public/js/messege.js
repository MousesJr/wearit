console.log('messege.js');
const messege = document.getElementById('messege');
var txt;
if(localStorage.windClass=='weak') {
    txt="It's not going to be a windy day today"
    console.log(localStorage.tempStatus);
    if(localStorage.tempStatus==1) {
        txt+=", but, it's going to be really cold. So, wear a good sweater, a jacket, a scarf and whatever more you'd like to, to protect yourself from the low temperatures and to keep warm";
    }
    if(localStorage.tempStatus==2) {
        txt+=", but, it's going to be cold. As a good advice, we recommend you to wear a jacket, or something like that, and a scarf, to keep your neck warm";
    }
    if(localStorage.tempStatus==3) {
        txt+=", such as not a strong cold day. We'd like to recommend you to wear a sweater, sweatshirt, jacket or whatever you'd like to in this type of clothing";
    }
    if(localStorage.tempStatus==4) {
        txt+=", and the temperatures are, considerabily good. Wearing some cooller clothes would be a good idea. But remember to carry with you a ligth jacket, or something like that";
    } else if(localStorage.tempStatus==5) {
        txt+=" and the temperatures are higher the usual. So, wear ligth clothes and don't mind carring with you any heavy ones";
        console.log('OEHO');
    }
}
if(localStorage.windClass=='moderated') {
    txt="It's going to wind a bit today"
    if(localStorage.tempStatus==1) {
        txt+=" and it's going to be really cold. So, wear a good sweater, a jacket, a scarf and whatever more you'd like to, to protect yourself from the low temperatures and to you keep warm";
    }
    if(localStorage.tempStatus==2) {
        txt+=", but, it's going to be cold. As a good advice, we recommend you to wear a jacket, or something like that, and a scarf (if think it is a good ideia) to keep your neck warm";
    }
    if(localStorage.tempStatus==3) {
        txt+=", but is not very cold. We'd like to recommend you to wear a sweater, sweatshirt, jacket or whatever you'd like to in this type of clothing";
    }
    if(localStorage.tempStatus==4) {
        txt+=", and the temperatures are good. Wearing some cooller clothes would be a good idea. But remember to carry with you a ligth jacket, or something like that";
    }
    if(localStorage.tempStatus==5) {
        txt+=" and the temperatures are higher the usual. So, wear ligth clothes and don't mind carring with you any heavy ones";
    }
}
if(localStorage.windClass=='strong') {
    txt="It's going to be a very windy day"
    if(localStorage.tempStatus==1) {
        txt+=",  as so really cold. Wear a good sweater, a jacket, a scarf and whatever more you'd like to, to protect yourself from the low temperatures and from the strong wind";
    }
    if(localStorage.tempStatus==2) {
        txt+=", with not very low temperatures, but the wind may make you feel cold. So, as a good advice, we strongly recommend you to wear a good jacket, or something like that, and a scarf";
    }
    if(localStorage.tempStatus==3) {
        txt+=", and the temperatures are really lower to be consider today as hot. The strong wind and the moderated temperatures, may make you feel cold. We'd like to recommend you to wear a sweater, sweatshirt, jacket or whatever you'd like to, in this type of clothing";
    }
    if(localStorage.tempStatus==4) {
        txt+=", and the temperatures are good, but the wind may, problably, make you feel colder than actually is. Wearing some cooller clothes will not be a good idea, so wear a jacket that can keep your protected from the strong wind";
    }
    if(localStorage.tempStatus==5) {
        txt+=", but the temperatures are higher than usual. So wear a sweatshirt, or anything like that, to keep you protected from the strong wind.";
    }
}
if(localStorage.windClass=='storm') {
    txt="WARNING: Going outside in a storm day is dangerous. Keep yourself protected inside your house";
}
txt += '.';
messege.textContent = txt;